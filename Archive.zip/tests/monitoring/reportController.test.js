import test from 'node:test';
import assert from 'node:assert/strict';
import { createIssuesController, createReportController } from '../../src/controllers/monitoring/index.js';
import { reportFilters } from '../../src/middlewares/validation/monitoring/index.js';
import { sessionFromRow, summarizeSessions } from '../../src/common/monitoring/reportData/index.js';
import { monitoringIssues, monitoringPage } from '../../src/models/monitoring/index.js';
import { fetchMonitoringPage, fetchMonitoringIssues } from '../../navbar/assets/js/monitoringApi.js';
import { displayedPagination, issuePage } from '../../navbar/assets/js/reportData.js';

function row(id = 'message-1') {
  return {
    session_id: `ai-monitor:v2:5687:${id}`,
    ticket_id: '5687',
    session_number: 1,
    report_date: new Date('2026-10-02T00:00:00Z'),
    updated_at: new Date('2026-10-02T12:00:00Z'),
    evaluated_at: new Date('2026-10-02T12:00:00Z'),
    ticket_subject: 'Fan support',
    score: 'satisfied'
  };
}

function response() {
  return {
    statusCode: 200,
    status(value) {
      this.statusCode = value;

      return this;
    },
    set() {
      return this;
    },
    json(value) {
      this.body = value;

      return this;
    }
  };
}

test('common-issue pages show at most fifteen ranked intents and share navigation state with session views', () => {
  const issues = Array.from({ length: 32 }, (_, index) => ({ intent_id: index.toString(16).padStart(64, '0'), session_count: 32 - index }));
  const state = {
    activeTab: 'issues',
    issues,
    issuesPage: 1,
    issuesLoaded: true,
    intentView: null,
    sessions: Array.from({ length: 15 }),
    page: 2,
    loaded: true,
    nextPagePosition: { cursor: 'next' }
  };
  const seen = [];
  for (let page = 1; page <= 3; page++) {
    state.issuesPage = page;
    const result = issuePage(state);
    seen.push(...result.rows);
    assert.equal(result.page, page);
    assert.equal(result.pages, 3);
    assert.equal(result.rows.length, page === 3 ? 2 : 15);
    const pagination = displayedPagination(state);
    assert.equal(pagination.hasPrevious, page > 1);
    assert.equal(pagination.hasNext, page < 3);
  }
  assert.deepEqual(seen, issues);
  // Refreshing a shorter ranking keeps the visible page within its new bounds.
  state.issues = issues.slice(0, 4);
  assert.equal(issuePage(state).page, 1);
  assert.equal(displayedPagination(state).hasNext, false);
  state.activeTab = 'sessions';
  assert.equal(displayedPagination(state).page, 2);
  assert.equal(displayedPagination(state).count, 15);
  assert.equal(displayedPagination(state).hasNext, true);
  state.activeTab = 'issues';
  state.intentView = { sessions: [row()], page: 1, loaded: true, nextPagePosition: null };
  assert.equal(displayedPagination(state).isIssues, false);
  assert.equal(displayedPagination(state).count, 1);
  assert.equal(displayedPagination(state).hasPrevious, false);
  assert.equal(displayedPagination(state).hasNext, false);
});

test('the shared session request uses a fifteen-row limit for directory and intent cursor pages', async () => {
  const intent = 'a'.repeat(64);
  const filters = { from: '2026-10-01', to: '2026-10-03' };
  const client = {
    async request(options) {
      const params = new URL(options.url).searchParams;
      assert.equal(params.get('limit'), '15');
      assert.equal(params.get('cursor'), 'saved-cursor');
      return {
        success: true,
        applied_filters: { intent: params.get('intent') },
        sessions: [{ ...row(), monitoring_status: 'evaluated', intent_id: params.get('intent') }],
        pagination: { has_more: false }
      };
    }
  };
  assert.equal((await fetchMonitoringPage(client, filters, { cursor: 'saved-cursor' })).sessions.length, 1);
  assert.equal((await fetchMonitoringPage(client, { ...filters, intent }, { cursor: 'saved-cursor' })).sessions.length, 1);
});

test('common issues hides the unidentified group while preserving full-search totals and percentages', async () => {
  const identified = {
    intent_id: 'a'.repeat(64),
    intent_name: 'Blown fuse in XYZ fan',
    product: 'XYZ fan',
    session_count: 1,
    percentage: 25
  };
  const unidentified = { intent_id: null, intent_name: 'Intent not identified', product: null, session_count: 3, percentage: 75 };
  let issues = [unidentified, identified];
  const client = { request: async () => ({ success: true, total_sessions: 4, issues }) };
  const filters = { from: '2026-10-01', to: '2026-10-07' };
  const result = await fetchMonitoringIssues(client, filters);
  assert.deepEqual(result.issues, [identified]);
  assert.equal(result.totalSessions, 4);
  assert.equal(result.issues[0].percentage, 25);
  issues = [unidentified];
  assert.deepEqual((await fetchMonitoringIssues(client, filters)).issues, []);
});

test('report serializes SQL timestamps and calculates page-scoped satisfaction', () => {
  const session = sessionFromRow(row());
  assert.equal(session.report_date, '2026-10-02');
  assert.equal(session.evaluated_at, '2026-10-02T12:00:00.000Z');
  assert.equal(session.record_id, session.session_id);
  assert.equal(session.issue_type, 'unknown');
  assert.equal(sessionFromRow({ ...row(), issue_type: 'payment' }).issue_type, 'payment');
  const summary = summarizeSessions([session]);
  assert.equal(summary.csat_percent, 100);
  assert.equal(summary.scope, 'page');
  assert.equal(Object.hasOwn(summary, 'resolution_breakdown'), false);
});

test('intent counts cover the full search, rank by frequency, and distinguish unclassified sessions', async () => {
  let receivedFilters;
  const controller = createIssuesController({
    db: {},
    readIssues: async (_db, filters) => {
      receivedFilters = filters;

      return [
        { intent_id: 'a'.repeat(64), intent_name: 'Blown fuse in XYZ fan', product: 'XYZ fan', session_count: '3' },
        { intent_id: null, intent_name: null, session_count: '7' },
        { intent_id: 'b'.repeat(64), intent_name: 'ABC fan does not power on', product: 'ABC fan', session_count: '25' }
      ];
    }
  });
  const res = response();
  await controller(
    {
      query: {
        from: '2026-10-01',
        to: '2026-10-07',
        score: 'neutral',
        search: ' product ',
        cursor: 'ignored',
        limit: '1'
      }
    },
    res
  );
  assert.equal(res.statusCode, 200);
  assert.equal(res.body.scope, 'search');
  assert.equal(res.body.total_sessions, 35);
  assert.deepEqual(
    res.body.issues.map(issue => [issue.intent_name, issue.session_count, issue.percentage]),
    [
      ['ABC fan does not power on', 25, 71.4],
      ['Intent not identified', 7, 20],
      ['Blown fuse in XYZ fan', 3, 8.6]
    ]
  );
  assert.equal(receivedFilters.after, null);
  assert.equal(receivedFilters.search, 'product');
  assert.equal(receivedFilters.score, 'neutral');
});

test('issues reject invalid filters before SQL and return empty or generic failure responses', async () => {
  let reads = 0;
  const controller = createIssuesController({
    db: {},
    readIssues: async () => {
      reads++;

      return [];
    }
  });
  const invalid = response();
  await controller({ query: { from: 'bad' } }, invalid);
  assert.equal(invalid.statusCode, 400);
  assert.equal(reads, 0);
  const empty = response();
  await controller({ query: { from: '2026-10-01', to: '2026-10-07' } }, empty);
  assert.equal(empty.body.total_sessions, 0);
  assert.deepEqual(empty.body.issues, []);
  const failed = response();
  await createIssuesController({
    db: {},
    readIssues: async () => {
      throw new Error('private SQL details');
    }
  })({ query: { from: '2026-10-01', to: '2026-10-07' } }, failed);
  assert.equal(failed.statusCode, 503);
  assert.doesNotMatch(JSON.stringify(failed.body), /private SQL/);
});

test('issue SQL shares literal text and score filters with sessions and has no pagination', async () => {
  let query;
  const values = {};
  const db = {
    request: () => ({
      input(name, _type, value) {
        values[name] = value;

        return this;
      },
      cancel() {},
      async query(value) {
        query = value;

        return { recordset: [] };
      }
    })
  };
  await monitoringIssues(db, {
    from: '2026-10-01',
    to: '2026-10-07',
    score: 'satisfied',
    search: "50%_[x]~'; DROP TABLE users;--",
    limit: 1,
    after: { session_id: 'ignored' }
  });
  assert.match(query, /GROUP BY e.intent_id, i.name, i.product, i.description/);
  assert.match(query, /ORDER BY session_count DESC, intent_name ASC/);
  assert.match(query, /LEFT JOIN .*bot_monitor_intents/);
  assert.doesNotMatch(query, /GROUP BY.*issue_type/);
  assert.doesNotMatch(query, /TOP|@after|@rowLimit|DROP TABLE users/);
  assert.equal(values.score, 'satisfied');
  assert.match(values.pattern, /50~%~_~\[x\]~~/);
  assert.equal(values.afterId, undefined);
  assert.ok(values.from instanceof Date);
});

test('date, score, search, page size and cursor are validated before SQL', () => {
  const query = { from: '2026-10-01', to: '2026-10-02' };
  for (const invalid of [
    { from: '2026-02-30' },
    { from: '2026-10-03' },
    { from: '2024-10-01' },
    { score: 'bad' },
    { search: 'x'.repeat(201) },
    { limit: '101' },
    { limit: '0' },
    { limit: '1; DROP TABLE sessions' },
    { intent: 'fan fuse' },
    { intent: ['unidentified'] },
    { intent: 'a'.repeat(63) },
    { cursor: 'not-json' }
  ]) {
    assert.throws(() => reportFilters({ ...query, ...invalid }), TypeError);
  }
  assert.equal(reportFilters(query).limit, 20);
  assert.equal(reportFilters({ ...query, intent: '' }).fingerprint, reportFilters(query).fingerprint);
  assert.equal(reportFilters({ ...query, intent: 'unidentified' }).intent, 'unidentified');
  assert.equal(reportFilters({ from: '2024-02-29', to: '2025-02-28' }).limit, 20);
  assert.throws(() => reportFilters({ from: '2024-02-29', to: '2025-03-01' }));
});

test('intent sessions reuse the report endpoint and cannot use another intent or directory cursor', async () => {
  const intent = 'a'.repeat(64);
  const query = { from: '2026-10-01', to: '2026-10-03', score: 'satisfied', search: 'fan', intent };
  const calls = [];
  const controller = createReportController({
    db: {},
    readPage: async (_db, filters) => {
      calls.push(filters);

      return {
        rows: [{ ...row(), intent_id: intent, intent_name: 'Blown fuse in XYZ fan', intent_product: 'XYZ fan' }],
        hasMore: !filters.after
      };
    }
  });
  const first = response();
  await controller({ query }, first);
  assert.equal(first.statusCode, 200);
  assert.equal(first.body.sessions[0].intent_id, intent);
  assert.equal(first.body.applied_filters.intent, intent);
  assert.equal(calls[0].intent, intent);
  assert.equal(calls[0].search, 'fan');
  assert.equal(calls[0].score, 'satisfied');
  const second = response();
  await controller({ query: { ...query, cursor: first.body.pagination.next_cursor } }, second);
  assert.equal(second.statusCode, 200);
  assert.equal(calls[1].after.session_id, row().session_id);
  assert.equal(second.body.pagination.next_cursor, null);
  for (const changedIntent of ['', 'b'.repeat(64), 'unidentified']) {
    const invalid = response();
    await controller({ query: { ...query, intent: changedIntent, cursor: first.body.pagination.next_cursor } }, invalid);
    assert.equal(invalid.statusCode, 400);
  }
  assert.equal(calls.length, 2);
});

test('the shared frontend page loader rejects ignored intent filters and unrelated sessions', async () => {
  const intent = 'a'.repeat(64);
  const filters = { from: '2026-10-01', to: '2026-10-03', score: 'neutral', search: 'fan', intent };
  const matching = { ...row(), monitoring_status: 'evaluated', intent_id: intent };
  const unrelated = { ...matching, session_id: 'ai-monitor:v2:5687:other', intent_id: 'b'.repeat(64) };
  const data = { success: true, applied_filters: { intent }, sessions: [matching], pagination: { has_more: false } };
  let result = data;
  const client = {
    async request(options) {
      const params = new URL(options.url).searchParams;
      assert.equal(params.get('intent'), filters.intent || null);
      assert.equal(params.get('from'), filters.from);
      assert.equal(params.get('score'), filters.score);
      assert.equal(params.get('search'), filters.search);

      return result;
    }
  };
  for (const invalid of [
    { ...data, applied_filters: undefined, sessions: [matching, unrelated] },
    { ...data, applied_filters: undefined, sessions: [] },
    { ...data, applied_filters: { intent: 'b'.repeat(64) } },
    { ...data, sessions: [matching, unrelated] },
    { ...data, sessions: [{ ...matching, intent_id: null }] }
  ]) {
    result = invalid;
    await assert.rejects(fetchMonitoringPage(client, filters), /backend did not apply the selected intent/);
  }
  result = data;
  const page = await fetchMonitoringPage(client, filters);
  assert.equal(page.sessions.length, 1);
  assert.equal(page.sessions[0].intentId, intent);
  assert.equal(page.next, null);
  filters.intent = 'unidentified';
  result = { ...data, applied_filters: { intent: 'unidentified' }, sessions: [{ ...matching, intent_id: null }] };
  assert.equal((await fetchMonitoringPage(client, filters)).sessions.length, 1);
  result = { ...result, sessions: [matching] };
  await assert.rejects(fetchMonitoringPage(client, filters), /backend did not apply the selected intent/);
  // Ordinary directory requests still work with an older response shape.
  delete filters.intent;
  result = { ...data, applied_filters: undefined, sessions: [matching, unrelated] };
  assert.equal((await fetchMonitoringPage(client, filters)).sessions.length, 2);
});

test('session SQL binds an exact intent or the unidentified group while keeping date, score, text and pagination filters', async () => {
  const values = {};
  const types = {};
  let query;
  const db = {
    request: () => ({
      input(name, type, value) {
        values[name] = value;
        types[name] = type;

        return this;
      },
      cancel() {},
      async query(value) {
        query = value;

        return { recordset: [row()] };
      }
    })
  };
  const filters = { from: '2026-10-01', to: '2026-10-03', score: 'neutral', search: 'fuse', limit: 20, after: null };
  for (const intent of ['a'.repeat(64), 'unidentified', '']) {
    await monitoringPage(db, { ...filters, intent });
    assert.equal(values.intent, intent);
    assert.equal(types.intent.length, 64);
    assert.equal(values.score, 'neutral');
    assert.equal(values.pattern, '%fuse%');
    assert.equal(values.rowLimit, 21);
    assert.match(query, /e.intent_id = @intent/);
    assert.match(query, /@intent = 'unidentified' AND e.intent_id IS NULL/);
    assert.match(query, /e.report_date BETWEEN @from AND @to/);
    assert.match(query, /@afterId IS NULL/);
    assert.doesNotMatch(query, /a{64}/);
  }
});

test('SQL report generates a next cursor tied to the same search filters', async () => {
  const query = { from: '2026-10-01', to: '2026-10-03', search: 'fan' };
  const calls = [];
  const controller = createReportController({
    db: {},
    readPage: async (_db, filters) => {
      calls.push(filters);

      return { rows: [row()], hasMore: !filters.after };
    }
  });
  const first = response();
  await controller({ query }, first);
  assert.equal(first.statusCode, 200);
  assert.equal(first.body.sessions.length, 1);
  assert.equal(first.body.applied_filters.intent, null);
  assert.equal(first.body.pagination.has_more, true);
  const second = response();
  await controller({ query: { ...query, cursor: first.body.pagination.next_cursor } }, second);
  assert.equal(second.body.pagination.next_cursor, null);
  assert.equal(calls[1].after.session_id, 'ai-monitor:v2:5687:message-1');
  const changedSearch = response();
  await controller(
    {
      query: {
        ...query,
        search: 'heater',
        cursor: first.body.pagination.next_cursor
      }
    },
    changedSearch
  );
  assert.equal(changedSearch.statusCode, 400);
  assert.equal(calls.length, 2);
});

test('SQL filtering uses bounded typed parameters and treats LIKE characters literally', async () => {
  let query;
  const values = {};
  const db = {
    request: () => ({
      input(name, _type, value) {
        values[name] = value;

        return this;
      },
      cancel() {},
      async query(value) {
        query = value;

        return { recordset: [row('one'), row('two')] };
      }
    })
  };
  const result = await monitoringPage(db, {
    from: '2026-10-01',
    to: '2026-10-03',
    score: 'satisfied',
    search: "50%_[x]~'; DROP TABLE users;--",
    limit: 1,
    after: null
  });
  assert.equal(result.rows.length, 1);
  assert.equal(result.hasMore, true);
  assert.equal(values.rowLimit, 2);
  assert.match(values.pattern, /50~%~_~\[x\]~~/);
  assert.doesNotMatch(query, /DROP TABLE users/);
  assert.match(query, /INNER JOIN .*bot_monitor_sessions/);
  assert.match(query, /ORDER BY e.report_date DESC, e.updated_at DESC, e.session_id DESC/);
});

test('database failure returns a generic 503 without SQL details', async () => {
  const controller = createReportController({
    db: {},
    readPage: async () => {
      throw new Error('private SQL details');
    }
  });
  const res = response();
  await controller({ query: { from: '2026-10-01', to: '2026-10-02' } }, res);
  assert.equal(res.statusCode, 503);
  assert.doesNotMatch(JSON.stringify(res.body), /private SQL/);
});
