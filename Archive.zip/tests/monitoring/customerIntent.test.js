import test from 'node:test';
import assert from 'node:assert/strict';
import axios from 'axios';
import { CLAUDE_CONFIG } from '../../src/config/claude/index.js';
import { customerIntent, customerIntentKey } from '../../src/common/monitoring/intent/index.js';
import { createMonitoringIntentResolver, matchCustomerIntent, extractCustomerIntent } from '../../src/services/monitoring/intents/index.js';
import { createMonitoringIntent, assignMonitoringIntent, readMonitoringIntentSessions } from '../../src/models/monitoring/intents/index.js';
import { backfillMonitoringIntents } from '../../scripts/backfillMonitoringIntents/backfill/index.js';

const fuse = {
  name: 'Blown fuse in XYZ fan',
  product: 'XYZ fan',
  description: 'The customer reports that the fuse in their XYZ fan has blown.'
};
const canonicalFuse = { ...fuse, intent_id: customerIntentKey(fuse) };

test('intent drafts accept specific new names, validate lengths, and preserve symptoms versus causes', () => {
  assert.deepEqual(customerIntent(fuse), fuse);
  assert.equal(customerIntent(null), null);
  for (const invalid of [
    undefined,
    'technical_support',
    {},
    { ...fuse, name: '' },
    { ...fuse, name: 'x'.repeat(241) },
    { ...fuse, product: 12 }
  ]) {
    assert.throws(() => customerIntent(invalid), /Invalid customer intent/);
  }
  assert.equal(customerIntentKey(fuse), customerIntentKey({ ...fuse, name: ` ${fuse.name.toUpperCase()} ` }));
  assert.notEqual(customerIntentKey(fuse), customerIntentKey({ ...fuse, product: 'ABC fan' }));
  assert.notEqual(
    customerIntentKey(fuse),
    customerIntentKey({ ...fuse, description: 'The customer asks where to buy a replacement fuse.' })
  );
});

test('identical drafts reuse the persistent catalogue after a resolver restart without another model call', async () => {
  const resolver = createMonitoringIntentResolver({
    list: async () => [canonicalFuse],
    match: () => {
      throw new Error('Identical evidence needs no semantic call');
    },
    create: () => {
      throw new Error('Existing intent must not be recreated');
    }
  });
  assert.equal(await resolver({ db: {}, draft: fuse }), canonicalFuse.intent_id);
});

test('paraphrased issues reuse a canonical intent after inspecting the entire catalogue in bounded batches', async () => {
  const catalogue = Array.from({ length: 161 }, (_, i) => ({
    intent_id: i.toString(16).padStart(64, '0'),
    name: `Different request ${i}`
  }));
  catalogue[80] = canonicalFuse;
  const checked = [];
  const draft = { ...fuse, name: 'XYZ fan fuse has burnt out' };
  const resolver = createMonitoringIntentResolver({
    list: async () => catalogue,
    match: async (intent, batch) => {
      assert.equal(intent.product, 'XYZ fan');
      checked.push(...batch);
      return batch.some(item => item.intent_id === canonicalFuse.intent_id) ? canonicalFuse.intent_id : null;
    },
    create: () => {
      throw new Error('A matching intent exists');
    }
  });
  assert.equal(await resolver({ db: {}, draft }), canonicalFuse.intent_id);
  assert.equal(checked.length, 161);
});

test('a new intent is created only after every existing intent was checked', async () => {
  const checked = [];
  const catalogue = [canonicalFuse];
  const different = {
    name: 'ABC heater does not power on',
    product: 'ABC heater',
    description: 'Customer reports their ABC heater does not start.'
  };
  const resolver = createMonitoringIntentResolver({
    list: async () => catalogue,
    match: async (draft, batch) => {
      checked.push(...batch);
      assert.equal(draft.product, 'ABC heater');
      return null;
    },
    create: async (_db, draft, count) => {
      assert.deepEqual(checked, catalogue);
      assert.equal(count, 1);
      return customerIntentKey(draft);
    }
  });
  assert.equal(await resolver({ db: {}, draft: different }), customerIntentKey(different));
});

test('concurrent catalogue additions are compared again instead of creating duplicate semantic groups', async () => {
  let reads = 0,
    inserts = 0;
  const resolver = createMonitoringIntentResolver({
    list: async () => (++reads === 1 ? [] : [canonicalFuse]),
    match: async () => canonicalFuse.intent_id,
    create: async () => {
      inserts++;
      return null;
    }
  });
  const draft = { ...fuse, name: 'XYZ fan fuse has burnt out' };
  assert.equal(await resolver({ db: {}, draft }), canonicalFuse.intent_id);
  assert.equal(reads, 2);
  assert.equal(inserts, 1);
});

test('failed matching and invalid IDs never create a new intent', async () => {
  for (const match of [
    async () => {
      throw new Error('Model unavailable');
    },
    async () => 'f'.repeat(64)
  ]) {
    const resolver = createMonitoringIntentResolver({
      list: async () => [canonicalFuse],
      match,
      create: () => {
        throw new Error('Must not create after an incomplete comparison');
      }
    });
    await assert.rejects(resolver({ db: {}, draft: { ...fuse, name: 'Fuse failed' } }), /Model unavailable|unknown catalogue ID/);
  }
});

test('unidentified requests remain unclassified and do not become artificial intent groups', async () => {
  const resolver = createMonitoringIntentResolver({
    extract: async () => null,
    list: () => {
      throw new Error('No identifiable request');
    }
  });
  assert.equal(await resolver({ db: {}, context: {} }), null);
});

test('model matching accepts only high-confidence supplied IDs and sends specific product/cause rules', async t => {
  const previousKey = CLAUDE_CONFIG.apiKey;
  CLAUDE_CONFIG.apiKey = 'test-only';
  t.after(() => {
    CLAUDE_CONFIG.apiKey = previousKey;
  });
  let output = { match_id: canonicalFuse.intent_id, confidence: 'high' };
  t.mock.method(axios, 'create', () => ({
    post: async (_path, payload) => {
      assert.match(payload.system, /different known\s+products\/models/);
      assert.match(payload.system, /confirmed\s+cause versus an unexplained symptom/);
      return { data: { content: [{ type: 'text', text: JSON.stringify(output) }] } };
    }
  }));
  assert.equal(await matchCustomerIntent(fuse, [canonicalFuse]), canonicalFuse.intent_id);
  output = { ...output, confidence: 'medium' };
  assert.equal(await matchCustomerIntent(fuse, [canonicalFuse]), null);
  output = { match_id: 'invented', confidence: 'high' };
  await assert.rejects(matchCustomerIntent(fuse, [canonicalFuse]), /invalid intent match/);
});

test('intent extraction uses customer evidence available at the original session end', async t => {
  const previousKey = CLAUDE_CONFIG.apiKey;
  CLAUDE_CONFIG.apiKey = 'test-only';
  t.after(() => {
    CLAUDE_CONFIG.apiKey = previousKey;
  });
  const ticketMessages = [
    { id: 'first', at: 1000, speaker: 'Customer', text: 'The fuse in my XYZ fan is blown' },
    { id: 'later', at: 9000, speaker: 'Customer', text: 'My ABC heater is now broken' }
  ];
  t.mock.method(axios, 'create', () => ({
    post: async (_path, payload) => {
      const input = JSON.parse(payload.messages[0].content);
      assert.deepEqual(
        input.ticket_conversation.map(message => message.id),
        ['first']
      );
      assert.match(payload.system, /not.*predefined category/);
      return { data: { content: [{ type: 'text', text: JSON.stringify({ customer_intent: fuse }) }] } };
    }
  }));
  const draft = await extractCustomerIntent({
    ticket: { id: 1 },
    session: { number: 1, startedAt: 1000, lastMessageAt: 1000, messages: [ticketMessages[0]] },
    ticketMessages
  });
  assert.deepEqual(draft, fuse);
});

test('catalogue creation binds customer data and serializes only the short SQL insert decision', async () => {
  const values = {};
  const db = {
    request: () => ({
      input(name, _type, value) {
        values[name] = value;
        return this;
      },
      cancel() {},
      async query(statement) {
        assert.match(statement, /sp_getapplock/);
        assert.match(statement, /COUNT_BIG\(\*\).*@expectedCount/);
        assert.match(statement, /ROLLBACK TRANSACTION/);
        assert.doesNotMatch(statement, /Blown fuse/);
        return { recordset: [{ intent_id: canonicalFuse.intent_id }] };
      }
    })
  };
  assert.equal(await createMonitoringIntent(db, fuse, 7), canonicalFuse.intent_id);
  assert.equal(values.expectedCount, 7);
  assert.equal(values.description, fuse.description);
});

test('historical assignment changes only intent fields and marks unidentified evidence as inspected', async () => {
  const values = {};
  const db = {
    request: () => ({
      input(name, _type, value) {
        values[name] = value;
        return this;
      },
      cancel() {},
      async query(statement) {
        assert.match(statement, /intent_classified_at IS NULL/);
        assert.doesNotMatch(statement, /SET.*(?:csat_score|reason|report_date|updated_at)\s*=/);
        return { recordset: [{ written: 1 }] };
      }
    })
  };
  assert.equal(await assignMonitoringIntent(db, 'session-1', null), true);
  assert.equal(values.intentId, null);
  assert.equal(values.replaceExisting, false);
  assert.equal(await assignMonitoringIntent(db, 'session-1', canonicalFuse.intent_id, { replaceExisting: true }), true);
  assert.equal(values.replaceExisting, true);
  assert.equal(values.intentId, canonicalFuse.intent_id);
});

test('history reads bind full-run options and a fixed cutoff without changing the pending-only default', async () => {
  const values = {};
  let query;
  const db = {
    request: () => ({
      input(name, _type, value) {
        values[name] = value;
        return this;
      },
      cancel() {},
      async query(statement) {
        query = statement;
        return { recordset: [] };
      }
    })
  };
  await readMonitoringIntentSessions(db);
  assert.equal(values.allSessions, false);
  assert.equal(values.before, null);
  assert.equal(values.after, '');
  const before = new Date('2026-10-12T12:00:00Z');
  await readMonitoringIntentSessions(db, 'session-50', { allSessions: true, before });
  assert.equal(values.allSessions, true);
  assert.equal(values.before, before);
  assert.equal(values.after, 'session-50');
  assert.match(query, /TOP \(50\)/);
  assert.match(query, /@allSessions = 1 OR e.intent_classified_at IS NULL/);
  assert.match(query, /e.updated_at <= @before/);
  assert.match(query, /e.session_id > @after/);
  assert.doesNotMatch(query, /UPDATE|DELETE|INSERT/);
});

test('full migration revisits each saved session once across pages and preserves valid intents when extraction is unclear', async () => {
  const start = Date.parse('2026-10-01T09:00:00Z');
  const rows = ['a', 'b', 'c', 'd'].map((id, index) => ({
    session_id: id,
    ticket_id: String(11 + index),
    first_message_id: 'first',
    last_message_at: new Date(start + 60_000),
    intent_id: index === 0 || index === 2 ? canonicalFuse.intent_id : null
  }));
  const reads = [];
  const classified = [];
  const assigned = [];
  const progress = [];
  const client = {
    async get(url) {
      if (!url.endsWith('/conversation_log')) return { data: { ticket: { id: Number(url.split('/').at(-1)), requester_id: 1 } } };
      return {
        data: {
          events: [
            {
              id: 'first',
              type: 'Messaging::ConversationMessage',
              created_at: new Date(start).toISOString(),
              author: { type: 'end-user' },
              content: { text: 'Fuse blown' }
            }
          ],
          meta: { has_more: false }
        }
      };
    }
  };
  const summary = await backfillMonitoringIntents({
    db: {},
    client,
    allSessions: true,
    read: async (_db, after, options) => {
      reads.push({ after, ...options });
      return rows.filter(row => row.session_id > after).slice(0, 2);
    },
    classify: async ({ context }) => {
      classified.push(context.ticket.id);
      return context.ticket.id < 13 ? 'b'.repeat(64) : null;
    },
    assign: async (_db, id, intentId, options) => {
      assert.equal(options.replaceExisting, true);
      assigned.push([id, intentId]);
      return true;
    },
    onProgress: counts => progress.push(counts)
  });
  assert.deepEqual(classified, [11, 12, 13, 14]);
  assert.deepEqual(assigned, [
    ['a', 'b'.repeat(64)],
    ['b', 'b'.repeat(64)],
    ['d', null]
  ]);
  assert.deepEqual(summary, { read: 4, classified: 2, unidentified: 1, unchanged: 1, failed: 0 });
  assert.deepEqual(
    reads.map(read => read.after),
    ['', 'b', 'd']
  );
  assert.ok(reads.every(read => read.allSessions && read.before instanceof Date && read.before === reads[0].before));
  assert.deepEqual(
    progress.map(counts => counts.read),
    [1, 2, 3, 4]
  );
});

test('historical backfill shares ticket reads, excludes later replies, and leaves missing evidence pending', async () => {
  const start = Date.parse('2026-10-01T09:00:00Z');
  const rows = ['first', 'missing'].map(id => ({
    session_id: id,
    ticket_id: '11',
    first_message_id: id,
    last_message_at: new Date(start + 60_000)
  }));
  let reads = 0;
  const assigned = [];
  const client = {
    async get(url) {
      reads++;
      if (url === '/tickets/11') return { data: { ticket: { id: 11, requester_id: 1 } } };
      return {
        data: {
          events: [
            {
              id: 'first',
              created_at: new Date(start).toISOString(),
              type: 'Messaging::ConversationMessage',
              author: { type: 'end-user' },
              content: { text: 'Fuse blown' }
            },
            {
              id: 'later',
              created_at: new Date(start + 3600_000).toISOString(),
              type: 'Messaging::ConversationMessage',
              author: { type: 'end-user' },
              content: { text: 'Different issue' }
            }
          ],
          meta: { has_more: false }
        }
      };
    }
  };
  const summary = await backfillMonitoringIntents({
    db: {},
    client,
    read: async (_db, after) => (after ? [] : rows),
    classify: async ({ context }) => {
      assert.deepEqual(
        context.ticketMessages.map(message => message.id),
        ['first']
      );
      return canonicalFuse.intent_id;
    },
    assign: async (_db, id, intent) => {
      assigned.push([id, intent]);
      return true;
    }
  });
  assert.equal(reads, 2);
  assert.deepEqual(assigned, [['first', canonicalFuse.intent_id]]);
  assert.equal(summary.classified, 1);
  assert.equal(summary.failed, 1);
});
