// js/: API access. This file validates report dates and fetches SQL sessions through the Zendesk proxy.
import { completedSessions, SATISFACTION_SCORES } from "./reportData.js";
import { MONITORING_API } from "./monitoringConfig.js";
import { formatCustomerIntent } from "./formatters.js";

/**
 * Read an exact YYYY-MM-DD date and reject invalid calendar dates.
 * @returns {Date|null} The date at UTC midnight, or null if the input is invalid.
 */
function parseDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || "")) return null;
  const date = new Date(`${value}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return null;
  if (date.toISOString().slice(0, 10) !== value) return null;
  return date;
}

/**
 * Check that report dates are valid, in order, and no more than one calendar year apart.
 * @returns {string|null} An error message, or null when the range is valid.
 */
export function validateDateRange(from, to) {
  const start = parseDate(from);
  const end = parseDate(to);
  if (!start || !end) return "Select a valid start and end report date.";
  if (start > end) return "The start date must be on or before the end date.";
  if (to > maxRangeDate(from))
    return "Select a date range of no more than one year.";
  return null;
}

/**
 * Calculate the latest allowed end date, including the February 29 leap-year case.
 * @returns {string} The maximum YYYY-MM-DD end date, or an empty string for an invalid start date.
 */
export function maxRangeDate(from) {
  const start = parseDate(from);
  if (!start) return "";
  const year = start.getUTCFullYear() + 1;
  const month = start.getUTCMonth();
  const day = Math.min(
    start.getUTCDate(),
    new Date(Date.UTC(year, month + 1, 0)).getUTCDate(),
  );
  return new Date(Date.UTC(year, month, day)).toISOString().slice(0, 10);
}

/**
 * Convert common API failures to a message the app can show to an agent.
 * @returns {string} A readable connection, authorization, or search error message.
 */
export function monitoringApiErrorMessage(error) {
  const status = Number(error?.status || error?.responseJSON?.status);
  if (status === 401 || status === 403)
    return "Report access was denied. Ask an administrator to update the app's secure monitoring API key to match the backend REPORT_API_KEY.";
  if (status === 404)
    return "The monitoring endpoint was not found. Restart the backend with the latest code, reload the app, and check the configured backend hostname.";
  if (status === 400)
    return "The monitoring API rejected this search. Check the dates and search text.";
  return (
    error?.message ||
    "Could not load monitoring data. Check the API configuration and try again."
  );
}

/**
 * Build the common date, text, and satisfaction parameters for both report views.
 * @returns {URLSearchParams} Applied filters, without a page cursor or limit.
 */
function reportParams(filters) {
  const params = new URLSearchParams({ from: filters.from, to: filters.to });
  if (filters.search?.trim()) params.set("search", filters.search.trim());
  if (filters.score) params.set("score", filters.score);
  if (filters.intent) params.set("intent", filters.intent);
  return params;
}

/**
 * Request a monitoring resource; Zendesk inserts the secure key outside the browser.
 * @returns {Promise<Object>} The backend JSON response. Rejects if the request fails.
 */
function requestMonitoring(client, path, params) {
  return client.request({
    url: `https://${MONITORING_API.hostname}/sunshine/monitoring/${path}?${params}`,
    type: "GET",
    dataType: "json",
    cache: false,
    autoRetry: true,
    headers: {
      Authorization: "Bearer {{setting.monitoring_api_key}}",
      "ngrok-skip-browser-warning": "1",
    },
    secure: true,
    cors: false,
  });
}

/**
 * Fetch one page of completed SQL sessions using the configured backend and Zendesk proxy.
 * @returns {Promise<Object>} Normalized sessions and the next cursor, or null when there is no next page. Throws if the request fails.
 */
export async function fetchMonitoringPage(
  client,
  filters,
  position = { cursor: null },
) {
  const error = validateDateRange(filters.from, filters.to);
  if (error) throw new Error(error);
  const params = reportParams(filters);
  params.set("limit", String(MONITORING_API.pageSize));
  if (position?.cursor) params.set("cursor", position.cursor);
  const response = await requestMonitoring(client, "sessions", params);
  if (response?.success !== true || !Array.isArray(response.sessions)) {
    throw new Error("The monitoring API returned an invalid response.");
  }
  // The table and Excel export share this check: an older backend must not
  // silently return the whole directory under a selected intent's heading.
  if (
    filters.intent &&
    (response.applied_filters?.intent !== filters.intent ||
      response.sessions.some((session) =>
        filters.intent === "unidentified"
          ? session.intent_id !== null
          : session.intent_id !== filters.intent,
      ))
  ) {
    throw new Error(
      "The backend did not apply the selected intent. Restart the server and reload the app.",
    );
  }
  const cursor = response.pagination?.next_cursor;
  if (
    response.pagination?.has_more &&
    (!cursor || cursor === position?.cursor)
  ) {
    throw new Error("Monitoring report pagination did not advance.");
  }
  return {
    sessions: completedSessions(response.sessions),
    next: response.pagination?.has_more ? { cursor } : null,
  };
}

/**
 * Fetch overview totals and both satisfaction breakdowns for the entire applied search.
 * @param {Object} client - Zendesk SDK client.
 * @param {Object} filters - Applied report dates, text, and satisfaction score.
 * @returns {Promise<Object>} Full-search totals in the dashboard's display format.
 */
export async function fetchMonitoringSummary(client, filters) {
  const error = validateDateRange(filters.from, filters.to);
  if (error) throw new Error(error);
  const response = await requestMonitoring(
    client,
    "summary",
    reportParams(filters),
  );
  const summary = response?.summary;
  const sessionScores = summary?.score_breakdown;
  const ticketScores = summary?.ticket_score_breakdown;
  const counts = [
    summary?.total_tickets,
    summary?.total_sessions,
    ...SATISFACTION_SCORES.flatMap((score) => [
      sessionScores?.[score],
      ticketScores?.[score],
    ]),
  ];
  if (
    response?.success !== true ||
    summary?.scope !== "search" ||
    counts.some((count) => !Number.isSafeInteger(count) || count < 0) ||
    !(
      summary.csat_percent === null ||
      (Number.isInteger(summary.csat_percent) &&
        summary.csat_percent >= 0 &&
        summary.csat_percent <= 100)
    ) ||
    Object.values(sessionScores).reduce((total, count) => total + count, 0) !==
      summary.total_sessions ||
    Object.values(ticketScores).reduce((total, count) => total + count, 0) !==
      summary.total_tickets
  ) {
    throw new Error("The monitoring API returned invalid full-search totals.");
  }
  return {
    tickets: summary.total_tickets,
    sessions: summary.total_sessions,
    satisfiedTickets: ticketScores.satisfied,
    ticketScores,
    sessionScores,
    estimatedSatisfactionPercent: summary.csat_percent,
  };
}

/**
 * Request customer intent counts, including sessions without a detected intent.
 * @returns {Promise<Object>} Ranked issues and totalSessions for the entire date range.
 */
export async function fetchMonitoringIssues(client, filters) {
  const error = validateDateRange(filters.from, filters.to);
  if (error) throw new Error(error);
  const response = await requestMonitoring(
    client,
    "issues",
    reportParams(filters),
  );
  if (
    response?.success !== true ||
    !Array.isArray(response.issues) ||
    !Number.isSafeInteger(response.total_sessions) ||
    response.total_sessions < 0
  ) {
    throw new Error("The monitoring API returned invalid issue counts.");
  }
  for (const issue of response.issues) {
    if (
      !(
        issue.intent_id === null ||
        (typeof issue.intent_id === "string" &&
          /^[a-f0-9]{64}$/.test(issue.intent_id))
      ) ||
      typeof issue.intent_name !== "string" ||
      !issue.intent_name.trim() ||
      !(issue.product === null || typeof issue.product === "string") ||
      !Number.isSafeInteger(issue.session_count) ||
      issue.session_count < 1 ||
      !Number.isFinite(issue.percentage) ||
      issue.percentage < 0 ||
      issue.percentage > 100
    ) {
      throw new Error("The monitoring API returned invalid issue counts.");
    }
  }
  return {
    issues: response.issues.map((issue) =>
      issue.intent_id === null
        ? { ...issue, intent_name: formatCustomerIntent(null) }
        : issue,
    ),
    totalSessions: response.total_sessions,
  };
}
